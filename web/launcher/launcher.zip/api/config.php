<?php
return array(
    'host' => 'localhost',
    'user' => 'u0237043_site',
    'pass' => '48!1NCCg',
    'port' => '3306',
	
    'auth' => 'auth',
    'characters' => 'characters',
    'world' => 'world',

	'news' => 'u0237043_nostaleLauncher', //Do not change ! Just create a database with the same name
    'site_url' => 'https://nostale.su/',  //Do not forget to put a slash at the end of the address
);

