<?php

define('DS',DIRECTORY_SEPARATOR);
define('ROOT',realpath(__DIR__).DS);
define('DISPLAY_ERROR',false);

require_once ROOT.'api'.DS.'bootstrap.php';

